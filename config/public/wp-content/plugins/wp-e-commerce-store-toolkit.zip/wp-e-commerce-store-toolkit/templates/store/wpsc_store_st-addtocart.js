var $j = jQuery.noConflict();

$j(function(){

	$j('input.wpsc_buy_button').val( 'Add to Cart 111' );

});