<div class="metabox-holder">
	<div id="offline_credit_card" class="postbox">
		<h3 class="hndle"><?php _e( 'Offline Credit Card Processing', 'wpsc_oc' ); ?></h3>
		<div class="inside">

			<p>[...]</p>

		</div>
	</div>
</div>