<?php
$prefix = 'wpsc_st';

delete_option( $prefix . '_demo_store' );
delete_option( $prefix . '_demo_store_text' );
delete_option( $prefix . '_sale_status_background' );
delete_option( $prefix . '_sale_status_border' );
?>